import logging
import os
from datetime import datetime

HOME_OPERATING_SYSTEM = 'nt'
LOG_LEVEL = logging.DEBUG
LOG_FILENAME = 'debugLog.txt'

class Log():
    def __init__(self):
        self.doNothing = False
        if os.name != HOME_OPERATING_SYSTEM:
            self.doNothing = True
        else:
            logging.basicConfig(filename = LOG_FILENAME, level = LOG_LEVEL)
            
            self.turnStartTime = datetime.now()
            self.turnNumber = 1
        
    def debug(self, s):
        if not self.doNothing:
            time = self.timeSinceTurnStart()
            logging.debug(time + ' : ' + s + '\n')
            
    def error(self, s):
        if not self.doNothing:
            time = self.timeSinceTurnStart()
            logging.error(time + ' : ' + s + '\n')
            
    def startTurn(self):
        if not self.doNothing:
            logging.debug('\n**Starting turn ' + str(self.turnNumber) + ' **\n\n')
            self.turnStartTime = datetime.now()
            self.turnNumber += 1
        
    def timeSinceTurnStart(self):
        timeDelta = (datetime.now() - self.turnStartTime)
        s = str(timeDelta.seconds)
        us = str(timeDelta.microseconds)
        time = s + '.' + '0' * (6-len(us)) + us
        
        return time

log = Log()